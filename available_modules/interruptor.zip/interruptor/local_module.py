# -*- coding: utf-8 -*-

from khome import module, fields

class Interruptor(module.Base):
    update_rate = 1

    class _state(fields.mode.Hidden, fields.sensor.Interruptor,
            fields.mode.Readable, fields.syntax.Integer,
            fields.persistant.Database, fields.Base):
        pass

    class state_a(fields.mode.Readable, fields.syntax.Numeric,
            fields.persistant.Volatile, fields.Base):
        sleep_on_start = 1
        update_rate = 0.1

        def acquire_value(self):
            try:
                v = int(self.module._state()[1]) & 0b0011
            except TypeError as e:
                self.module.logger.exception(e)
                return

            # state -> return code
            if v == 1:
                return -1
            if v == 2:
                return 1
            return 0

    class state_b(fields.mode.Readable, fields.syntax.Numeric,
            fields.persistant.Volatile, fields.Base):
        sleep_on_start = 1
        update_rate = 0.1

        def acquire_value(self):
            try:
                v = int(self.module._state()[1]) & 0b1100
            except TypeError:
                self.module.logger.exception(e)
                return

            # state -> return code
            if v == 4:
                return -1
            if v == 8:
                return 1
            return 0
